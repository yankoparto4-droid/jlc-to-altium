﻿param([string]$Name = '嘉立创转AD.lnk')

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSCommandPath
$tool = Join-Path $root 'JLC2AD'
$target = Join-Path $tool '嘉立创转AD.cmd'
$icon = Join-Path $tool 'whale-girl.ico'

if (-not (Test-Path $target)) { Write-Error "找不到启动文件: $target"; exit 1 }
if (-not (Test-Path $icon)) { Write-Warning "找不到图标文件: $icon（将使用默认图标）" }

$desktop = [Environment]::GetFolderPath('Desktop')
$lnkPath = Join-Path $desktop $Name

$ws = New-Object -ComObject WScript.Shell
$s = $ws.CreateShortcut($lnkPath)
$s.TargetPath = $target
$s.WorkingDirectory = $tool
if (Test-Path $icon) { $s.IconLocation = "$icon,0" }
$s.Description = '嘉立创元件转 Altium Designer 库'
$s.Save()

Write-Host ""
Write-Host "已创建快捷方式: $lnkPath"
Write-Host "  目标: $target"
if (Test-Path $icon) { Write-Host "  图标: $icon" }
