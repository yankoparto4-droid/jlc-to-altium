﻿param(
  [Parameter(Mandatory = $true, Position = 0)][string]$Query,
  [string]$Output = '',
  [int]$Index = 1,
  [switch]$No3D
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSCommandPath
$npnp = Join-Path $root 'npnp.exe'
$cfgFile = Join-Path $root 'config.json'

if (-not (Test-Path $npnp)) { Write-Error "npnp.exe 不存在: $npnp"; exit 1 }

if (-not $Output) {
  if (Test-Path $cfgFile) {
    try { $Output = (Get-Content $cfgFile -Raw -Encoding UTF8 | ConvertFrom-Json).output } catch { }
  }
  if (-not $Output) { $Output = 'D:\PCB\AD_Libs' }
}
New-Item -ItemType Directory -Force -Path $Output | Out-Null

# 没显式给 -No3D 时跟随 config.json 的设置（GUI 里勾过的就是这里读到的值）
if (-not $PSBoundParameters.ContainsKey('No3D')) {
  if (Test-Path $cfgFile) {
    try { $No3D = [bool](Get-Content $cfgFile -Raw -Encoding UTF8 | ConvertFrom-Json).no3d } catch { }
  }
}

Write-Host "查询: $Query"
$outFile = Join-Path $env:TEMP ("jlc2ad_" + [guid]::NewGuid().ToString('N') + ".txt")
$savedProxy = @{}
if ($No3D) {
  Write-Host "不导入 3D 模型（只导出符号和封装）" -ForegroundColor Cyan
  foreach ($k in @('HTTP_PROXY', 'HTTPS_PROXY', 'ALL_PROXY', 'NO_PROXY')) { $savedProxy[$k] = [Environment]::GetEnvironmentVariable($k, 'Process') }
  foreach ($k in @('HTTP_PROXY', 'HTTPS_PROXY', 'ALL_PROXY')) { Set-Item -Path ("Env:" + $k) -Value 'http://127.0.0.1:1' }
  Set-Item -Path 'Env:NO_PROXY' -Value 'pro.lceda.cn,lcsc.com,www.lcsc.com,item.szlcsc.com,szlcsc.com,www.szlcsc.com'
}
try {
  $p = Start-Process -FilePath $npnp -ArgumentList @('altium', $Query, '--index', "$Index", '--full', '--output', $Output, '--force') -NoNewWindow -Wait -PassThru -RedirectStandardOutput $outFile -RedirectStandardError "$outFile.err"
  $code = $p.ExitCode
  $text = if (Test-Path $outFile) { Get-Content $outFile -Raw -Encoding UTF8 } else { '' }
  if ($text) { Write-Host $text.Trim() }
  if (Test-Path "$outFile.err") {
    $err = Get-Content "$outFile.err" -Raw -Encoding UTF8
    if ($err -and $err.Trim()) { Write-Host $err.Trim() -ForegroundColor Yellow }
  }
  Write-Host "退出码: $code"
  Write-Host "输出目录: $Output"
  exit $code
} finally {
  Remove-Item $outFile, "$outFile.err" -Force -ErrorAction SilentlyContinue
  foreach ($k in $savedProxy.Keys) {
    if ($null -eq $savedProxy[$k]) { Remove-Item ("Env:" + $k) -ErrorAction SilentlyContinue }
    else { Set-Item -Path ("Env:" + $k) -Value $savedProxy[$k] }
  }
}
