﻿param([switch]$SelfTest, [string]$BomTest, [string]$ManualTest, [switch]$ConvertTest)

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$script:Root = Split-Path -Parent $PSCommandPath
$script:Npnp = Join-Path $script:Root 'npnp.exe'
$script:CfgFile = Join-Path $script:Root 'config.json'
$script:Busy = $false
$script:Loading = $true
$script:AutoYes = ([bool]$SelfTest -or [bool]$ConvertTest)

# 「不导入 3D」时放行的主机：只保留立创接口，3D 模型走 modules.lceda.cn / modules.easyeda.com
$script:No3DKeepHosts = 'pro.lceda.cn,lcsc.com,www.lcsc.com,item.szlcsc.com,szlcsc.com,www.szlcsc.com'

# ---------- 深海底色 ----------
$C_BG      = [System.Drawing.Color]::FromArgb(16, 28, 51)
$C_HEADER  = [System.Drawing.Color]::FromArgb(22, 41, 74)
$C_CARD    = [System.Drawing.Color]::FromArgb(26, 46, 80)
$C_FIELD   = [System.Drawing.Color]::FromArgb(18, 33, 59)
$C_STROKE  = [System.Drawing.Color]::FromArgb(44, 69, 112)
$C_TEXT    = [System.Drawing.Color]::FromArgb(237, 242, 251)
$C_MUTED   = [System.Drawing.Color]::FromArgb(157, 178, 212)
$C_ACCENT  = [System.Drawing.Color]::FromArgb(79, 195, 240)
$C_ACCENT2 = [System.Drawing.Color]::FromArgb(169, 200, 236)
$C_DARKTXT = [System.Drawing.Color]::FromArgb(11, 23, 48)
$C_BTN2    = [System.Drawing.Color]::FromArgb(35, 64, 106)
$C_BTN2H   = [System.Drawing.Color]::FromArgb(46, 82, 134)

$F_UI   = New-Object System.Drawing.Font('Microsoft YaHei UI', 9.5)
$F_BOLD = New-Object System.Drawing.Font('Microsoft YaHei UI', 10, [System.Drawing.FontStyle]::Bold)
$F_MONO = New-Object System.Drawing.Font('Consolas', 9.5)

function New-RoundPath([int]$w, [int]$h, [int]$r) {
  $p = New-Object System.Drawing.Drawing2D.GraphicsPath
  $d = $r * 2
  if ($d -gt $w) { $d = $w }; if ($d -gt $h) { $d = $h }
  $p.AddArc(0, 0, $d, $d, 180, 90)
  $p.AddArc($w - $d, 0, $d, $d, 270, 90)
  $p.AddArc($w - $d, $h - $d, $d, $d, 0, 90)
  $p.AddArc(0, $h - $d, $d, $d, 90, 90)
  $p.CloseFigure()
  return $p
}

function Set-Rounded($ctrl, [int]$radius) {
  try { $ctrl.Region = New-Object System.Drawing.Region (New-RoundPath $ctrl.Width $ctrl.Height $radius) } catch { }
}

function New-Card([int]$x, [int]$y, [int]$w, [int]$h) {
  $panel = New-Object System.Windows.Forms.Panel
  $panel.Location = New-Object System.Drawing.Point($x, $y)
  $panel.Size = New-Object System.Drawing.Size($w, $h)
  $panel.BackColor = $C_CARD
  Set-Rounded $panel 12
  return $panel
}

function New-Label([string]$text, [int]$x, [int]$y, $font, $color) {
  $l = New-Object System.Windows.Forms.Label
  $l.Text = $text
  $l.Location = New-Object System.Drawing.Point($x, $y)
  $l.AutoSize = $true
  $l.Font = $font
  $l.ForeColor = $color
  $l.BackColor = [System.Drawing.Color]::Transparent
  return $l
}

function New-FlatButton([string]$text, [int]$x, [int]$y, [int]$w, [int]$h, [bool]$primary) {
  $b = New-Object System.Windows.Forms.Button
  $b.Text = $text
  $b.Location = New-Object System.Drawing.Point($x, $y)
  $b.Size = New-Object System.Drawing.Size($w, $h)
  $b.FlatStyle = 'Flat'
  $b.UseVisualStyleBackColor = $false
  $b.Font = $F_BOLD
  $b.Cursor = [System.Windows.Forms.Cursors]::Hand
  $b.FlatAppearance.BorderSize = 0
  if ($primary) {
    $b.BackColor = $C_ACCENT
    $b.ForeColor = $C_DARKTXT
    $b.FlatAppearance.MouseOverBackColor = [System.Drawing.Color]::FromArgb(130, 214, 248)
    $b.FlatAppearance.MouseDownBackColor = [System.Drawing.Color]::FromArgb(45, 150, 200)
    $b.Tag = @{ normal = $C_ACCENT; hover = [System.Drawing.Color]::FromArgb(130, 214, 248) }
  } else {
    $b.BackColor = [System.Drawing.Color]::FromArgb(35, 64, 106)
    $b.ForeColor = $C_TEXT
    $b.FlatAppearance.BorderSize = 0
    $b.FlatAppearance.MouseOverBackColor = [System.Drawing.Color]::FromArgb(46, 82, 134)
    $b.FlatAppearance.MouseDownBackColor = [System.Drawing.Color]::FromArgb(28, 52, 88)
    $b.Tag = @{ normal = [System.Drawing.Color]::FromArgb(35, 64, 106); hover = [System.Drawing.Color]::FromArgb(46, 82, 134) }
  }
  $b.Add_MouseEnter({ $this.BackColor = $this.Tag.hover })
  $b.Add_MouseLeave({ $this.BackColor = $this.Tag.normal })
  Set-Rounded $b 8
  return $b
}

function New-Field([int]$x, [int]$y, [int]$w, [int]$h, [bool]$multiline) {
  $wrap = New-Object System.Windows.Forms.Panel
  $wrap.Location = New-Object System.Drawing.Point($x, $y)
  $wrap.Size = New-Object System.Drawing.Size($w, $h)
  $wrap.BackColor = $C_STROKE
  Set-Rounded $wrap 8

  $t = New-Object System.Windows.Forms.TextBox
  $t.Location = New-Object System.Drawing.Point(1, 1)
  $tw = $w - 2
  $th = $h - 2
  $t.Size = New-Object System.Drawing.Size($tw, $th)
  $t.BorderStyle = 'None'
  $t.BackColor = $C_FIELD
  $t.ForeColor = $C_TEXT
  $t.Font = $F_MONO
  if ($multiline) {
    $t.Multiline = $true
    $t.ScrollBars = 'Vertical'
    $t.AcceptsReturn = $true
  }
  $wrap.Controls.Add($t)
  $wrap.Tag = $t
  return $wrap
}

# ---------- 配置 ----------
function Get-Config {
  $cfg = [pscustomobject]@{ output = 'D:\PCB\AD_Libs'; libName = 'ADLib'; append = $true; no3d = $false }
  if (Test-Path $script:CfgFile) {
    try {
      $raw = Get-Content $script:CfgFile -Raw -Encoding UTF8 | ConvertFrom-Json
      if ($raw.output) { $cfg.output = [string]$raw.output }
      if ($raw.libName) { $cfg.libName = [string]$raw.libName }
      if ($null -ne $raw.append) { $cfg.append = [bool]$raw.append }
      if ($null -ne $raw.no3d) { $cfg.no3d = [bool]$raw.no3d }
    } catch { }
  }
  return $cfg
}

function Save-Config {
  try {
    $obj = [pscustomobject]@{
      output  = $script:TxtOutput.Text.Trim()
      libName = $script:TxtLib.Text.Trim()
      append  = [bool]$script:ChkAppend.Checked
      no3d    = [bool]$script:ChkNo3D.Checked
    }
    ($obj | ConvertTo-Json) | Set-Content -LiteralPath $script:CfgFile -Encoding UTF8
  } catch {
    Write-Log "保存设置失败：$($_.Exception.Message)"
  }
}

function Invoke-Npnp([string[]]$arguments) {
  $out = Join-Path $env:TEMP ("jlc2ad_" + [guid]::NewGuid().ToString('N'))
  $err = $out + '.err'
  $code = -1
  try {
    $p = Start-Process -FilePath $script:Npnp -ArgumentList $arguments -NoNewWindow -Wait -PassThru -RedirectStandardOutput $out -RedirectStandardError $err
    $code = $p.ExitCode
    $text = if (Test-Path $out) { Get-Content $out -Raw -Encoding UTF8 } else { '' }
    $etext = if (Test-Path $err) { Get-Content $err -Raw -Encoding UTF8 } else { '' }
    if ($null -eq $text) { $text = '' }
    if ($null -eq $etext) { $etext = '' }
    return [pscustomobject]@{ Code = $code; Out = $text; Err = $etext }
  } finally {
    Remove-Item $out, $err -Force -ErrorAction SilentlyContinue
  }
}

# 让 npnp 的 3D 模型下载失败（其余接口照常）：npnp 拿不到 STEP 时只导出符号/封装，不写 3D。
# 做法是把进程代理指向一个死地址，只用 NO_PROXY 放行立创接口域名。
function Invoke-NpnpNoModel([string[]]$arguments) {
  $saved = @{}
  foreach ($k in @('HTTP_PROXY', 'HTTPS_PROXY', 'ALL_PROXY', 'NO_PROXY')) {
    $saved[$k] = [Environment]::GetEnvironmentVariable($k, 'Process')
  }
  try {
    foreach ($k in @('HTTP_PROXY', 'HTTPS_PROXY', 'ALL_PROXY')) { Set-Item -Path ("Env:" + $k) -Value 'http://127.0.0.1:1' }
    Set-Item -Path 'Env:NO_PROXY' -Value $script:No3DKeepHosts
    return Invoke-Npnp $arguments
  } finally {
    foreach ($k in $saved.Keys) {
      if ($null -eq $saved[$k]) { Remove-Item ("Env:" + $k) -ErrorAction SilentlyContinue }
      else { Set-Item -Path ("Env:" + $k) -Value $saved[$k] }
    }
  }
}

# 库里是否还有嵌入的 STEP 数据（只做粗查，用于给「不导入 3D」一个确认）
function Test-PcbLibHasStep([string]$path) {
  $needle = 'ISO-10303-21'
  $keep = $needle.Length - 1
  $carry = ''
  try {
    $fs = [IO.File]::Open($path, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite)
  } catch { return $null }
  try {
    $buf = New-Object byte[] 262144
    while (($n = $fs.Read($buf, 0, $buf.Length)) -gt 0) {
      $text = $carry + [Text.Encoding]::ASCII.GetString($buf, 0, $n)
      if ($text.IndexOf($needle) -ge 0) { return $true }
      $carry = if ($text.Length -gt $keep) { $text.Substring($text.Length - $keep) } else { $text }
    }
    return $false
  } catch {
    return $null
  } finally {
    $fs.Dispose()
  }
}

function Write-Log([string]$message) {
  $stamp = Get-Date -Format 'HH:mm:ss'
  $script:Log.SelectionStart = $script:Log.TextLength
  $script:Log.SelectionColor = $C_MUTED
  $script:Log.AppendText("[$stamp] ")
  $script:Log.SelectionColor = $C_TEXT
  $script:Log.AppendText("$message`r`n")
  $script:Log.SelectionStart = $script:Log.Text.Length
  $script:Log.ScrollToCaret()
  [System.Windows.Forms.Application]::DoEvents()
}

function Set-Busy([bool]$state) {
  $script:Busy = $state
  foreach ($c in @($script:BtnSearch, $script:BtnConvert, $script:BtnConvertSel, $script:BtnBrowse, $script:TxtInput, $script:ChkNo3D)) { $c.Enabled = -not $state }
  $script:Cursor = if ($state) { [System.Windows.Forms.Cursors]::WaitCursor } else { [System.Windows.Forms.Cursors]::Default }
  [System.Windows.Forms.Application]::DoEvents()
}

function Resolve-Cid([string]$token) {
  if ($token -match '^[Cc]\d+$') { return $token.ToUpper() }
  $r = Invoke-Npnp @('search', $token, '--limit', '1')
  $m = [regex]::Match($r.Out, 'LCSC ID:\s*(C\d+)')
  if ($m.Success) { return $m.Groups[1].Value }
  return $null
}

# ---------- 窗口 ----------
$form = New-Object System.Windows.Forms.Form
$form.Text = '嘉立创 → Altium Designer'
$form.ClientSize = New-Object System.Drawing.Size(820, 874)
$form.StartPosition = 'CenterScreen'
$form.BackColor = $C_BG
$form.ForeColor = $C_TEXT
$form.Font = $F_UI
$form.AutoScaleMode = 'None'
$form.MinimumSize = New-Object System.Drawing.Size(836, 912)

$header = New-Object System.Windows.Forms.Panel
$header.Location = New-Object System.Drawing.Point(0, 0)
$header.Size = New-Object System.Drawing.Size(820, 150)
$header.BackColor = $C_HEADER
function Get-MascotFile {
  foreach ($ext in @('png', 'jpg', 'jpeg', 'webp', 'bmp', 'gif')) {
    $f = Join-Path $script:Root ('whale-girl.' + $ext)
    if (Test-Path $f) { return $f }
  }
  return $null
}
function Set-Mascot($picBox) {
  $f = Get-MascotFile
  if (-not $f) { return }
  try {
    if ($picBox.Image) { $oldImg = $picBox.Image; $picBox.Image = $null; $oldImg.Dispose() }
    if ($f -match '\.webp$') {
    $ff = 'C:\Program Files\ffmpeg\bin\ffmpeg.exe'
    if (Test-Path $ff) {
      $tmp = Join-Path $env:TEMP 'jlc2ad_mascot_conv.png'
      Start-Process -FilePath $ff -ArgumentList @('-y', '-loglevel', 'error', '-i', $f, $tmp) -Wait -NoNewWindow
      if (Test-Path $tmp) { $f = $tmp }
    }
  }
  $bytes = [IO.File]::ReadAllBytes($f)
    $ms = New-Object System.IO.MemoryStream (,$bytes)
    $picBox.Image = [System.Drawing.Image]::FromStream($ms)
  } catch { }
}
$pic = New-Object System.Windows.Forms.PictureBox
$pic.Location = New-Object System.Drawing.Point(14, 10)
$pic.Size = New-Object System.Drawing.Size(128, 128)
$pic.SizeMode = 'Zoom'
$pic.Cursor = [System.Windows.Forms.Cursors]::Hand
$pic.BackColor = [System.Drawing.Color]::Transparent
$pic.Add_Click({ Set-Mascot $pic })
Set-Mascot $pic
$tip = New-Object System.Windows.Forms.ToolTip
$tip.SetToolTip($pic, '点头像重新载入 whale-girl.png/jpg')
try {
  $mf = Get-MascotFile
  if ($mf) {
    $ibytes = [IO.File]::ReadAllBytes($mf)
    $ims = New-Object System.IO.MemoryStream (,$ibytes)
    $srcImg = [System.Drawing.Image]::FromStream($ims)
    $ib = New-Object System.Drawing.Bitmap 64, 64
    $igfx = [System.Drawing.Graphics]::FromImage($ib)
    $igfx.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $igfx.DrawImage($srcImg, 0, 0, 64, 64)
    $igfx.Dispose(); $srcImg.Dispose()
    $form.Icon = [System.Drawing.Icon]::FromHandle($ib.GetHicon())
    $ib.Dispose()
  }
} catch { }
$header.Controls.Add($pic)
$header.Controls.Add((New-Label '嘉立创元件 → Altium Designer' 158 30 (New-Object System.Drawing.Font('Microsoft YaHei UI', 18, [System.Drawing.FontStyle]::Bold)) $C_TEXT))
$header.Controls.Add((New-Label '批量抓取立创元件，合并为一个 AD 库' 160 76 $F_UI $C_MUTED))
$header.Controls.Add((New-Label 'npnp v3.1.0' 712 116 $F_UI $C_STROKE))
$form.Controls.Add($header)

$line = New-Object System.Windows.Forms.Panel
$line.Location = New-Object System.Drawing.Point(0, 150)
$line.Size = New-Object System.Drawing.Size(820, 2)
$line.BackColor = $C_ACCENT
$form.Controls.Add($line)

$cardInput = New-Card 16 168 788 192
$cardInput.Controls.Add((New-Label '输入元件（一行一个），或直接把 BOM 文件拖进来' 14 10 $F_UI $C_MUTED))
$fieldInput = New-Field 14 36 760 100 $true
$script:TxtInput = $fieldInput.Tag
$cardInput.Controls.Add($fieldInput)
$script:BtnSearch = New-FlatButton '搜索候选' 14 146 108 34 $false
$script:Status = New-Label '就绪' 134 154 $F_UI $C_ACCENT2
$cardInput.Controls.Add($script:BtnSearch)
$cardInput.Controls.Add($script:Status)
$form.Controls.Add($cardInput)

$cardList = New-Card 16 374 788 152
$cardList.Controls.Add((New-Label '搜索结果（可 Ctrl / Shift 多选）' 14 8 $F_UI $C_MUTED))
$script:ListResults = New-Object System.Windows.Forms.ListBox
$script:ListResults.Location = New-Object System.Drawing.Point(14, 32)
$script:ListResults.Size = New-Object System.Drawing.Size(760, 108)
$script:ListResults.BackColor = $C_FIELD
$script:ListResults.ForeColor = $C_TEXT
$script:ListResults.BorderStyle = 'None'
$script:ListResults.Font = $F_UI
$script:ListResults.SelectionMode = 'MultiExtended'
$script:ListResults.DisplayMember = 'Text'
$script:ListResults.ValueMember = 'Cid'
$script:ListResults.DrawMode = 'OwnerDrawFixed'
$script:ListResults.ItemHeight = 26
$cardList.Controls.Add($script:ListResults)
$form.Controls.Add($cardList)

$cardCfg = New-Card 16 540 788 126
$cardCfg.Controls.Add((New-Label '输出文件夹' 14 12 $F_UI $C_MUTED))
$fieldOut = New-Field 14 34 596 30 $false
$script:TxtOutput = $fieldOut.Tag
$script:BtnBrowse = New-FlatButton '浏览…' 620 33 76 32 $false
$script:BtnOpen = New-FlatButton '打开' 702 33 72 32 $false
$cardCfg.Controls.Add($fieldOut)
$cardCfg.Controls.Add($script:BtnBrowse)
$cardCfg.Controls.Add($script:BtnOpen)

$cardCfg.Controls.Add((New-Label '库名' 14 82 $F_UI $C_MUTED))
$fieldLib = New-Field 56 80 140 30 $false
$script:TxtLib = $fieldLib.Tag
$script:ChkAppend = New-Object System.Windows.Forms.CheckBox
$script:ChkAppend.Text = '追加到已有库（不勾选则覆盖重建）'
$script:ChkAppend.Location = New-Object System.Drawing.Point(212, 84)
$script:ChkAppend.AutoSize = $true
$script:ChkAppend.ForeColor = $C_TEXT
$script:ChkAppend.BackColor = [System.Drawing.Color]::Transparent
$cardCfg.Controls.Add($fieldLib)
$cardCfg.Controls.Add($script:ChkAppend)

$script:ChkNo3D = New-Object System.Windows.Forms.CheckBox
$script:ChkNo3D.Text = '不导入 3D 模型'
$script:ChkNo3D.Location = New-Object System.Drawing.Point(470, 84)
$script:ChkNo3D.AutoSize = $true
$script:ChkNo3D.ForeColor = $C_TEXT
$script:ChkNo3D.BackColor = [System.Drawing.Color]::Transparent
$script:ChkNo3D.Cursor = [System.Windows.Forms.Cursors]::Hand
$cardCfg.Controls.Add($script:ChkNo3D)
$tip.SetToolTip($script:ChkNo3D, '勾选后不下载、不嵌入 STEP 模型：库更小、转换更快。已有库里的 3D 不受影响。')
$form.Controls.Add($cardCfg)

$script:BtnConvert = New-FlatButton '批量转换并合并' 16 682 196 44 $true
$script:BtnConvertSel = New-FlatButton '仅转换选中项' 224 682 152 44 $false
$form.Controls.Add($script:BtnConvert)
$form.Controls.Add($script:BtnConvertSel)

$script:BtnBom = New-FlatButton '导入 BOM…' 380 682 140 44 $false
$form.Controls.Add($script:BtnBom)

$script:BtnManual = New-FlatButton '导出待手工…' 530 682 150 44 $false
$form.Controls.Add($script:BtnManual)

$cardLog = New-Card 16 738 788 120
$cardLog.Controls.Add((New-Label '运行日志' 14 8 $F_UI $C_MUTED))
$script:Log = New-Object System.Windows.Forms.RichTextBox
$script:Log.Location = New-Object System.Drawing.Point(14, 30)
$script:Log.Size = New-Object System.Drawing.Size(760, 80)
$script:Log.ScrollBars = 'Vertical'
$script:Log.ReadOnly = $true
$script:Log.BorderStyle = 'None'
$script:Log.BackColor = $C_FIELD
$script:Log.ForeColor = $C_TEXT
$script:Log.Font = $F_MONO
$cardLog.Controls.Add($script:Log)
$form.Controls.Add($cardLog)

$script:ListResults.Add_DrawItem({
  param($sender, $e)
  if ($e.Index -lt 0) { return }
  $item = $sender.Items[$e.Index]
  $selected = ($e.State -band [System.Windows.Forms.DrawItemState]::Selected) -ne 0
  $bg = if ($selected) { $C_ACCENT } elseif ($e.Index % 2 -eq 0) { $C_FIELD } else { [System.Drawing.Color]::FromArgb(22, 39, 68) }
  $fg = if ($selected) { $C_DARKTXT } else { $C_TEXT }
  $brushBg = New-Object System.Drawing.SolidBrush $bg
  $brushFg = New-Object System.Drawing.SolidBrush $fg
  $e.Graphics.FillRectangle($brushBg, $e.Bounds)
  $rect = New-Object System.Drawing.RectangleF ($e.Bounds.X + 10), ($e.Bounds.Y + 4), ($e.Bounds.Width - 16), ($e.Bounds.Height - 8)
  $e.Graphics.DrawString($item.Text, $F_UI, $brushFg, $rect)
  $brushBg.Dispose()
  $brushFg.Dispose()
})

# ---------- 初始化 ----------
$cfg = Get-Config
$script:TxtOutput.Text = $cfg.output
$script:TxtLib.Text = $cfg.libName
$script:ChkAppend.Checked = $cfg.append
$script:ChkNo3D.Checked = $cfg.no3d
$script:Loading = $false

# ---------- 行为 ----------
function Do-Search {
  $q = ($script:TxtInput.Text -split "`r?`n" | Where-Object { $_.Trim() } | Select-Object -First 1)
  if (-not $q) { return }
  $q = $q.Trim()
  $script:ListResults.Items.Clear()
  Set-Busy $true
  $script:Status.Text = '搜索中…'
  try {
    $r = Invoke-Npnp @('search', $q, '--limit', '20')
    $lines = @($r.Out -split "`r?`n" | Where-Object { $_ -match '^\s*\[\s*\d+\]' })
    foreach ($line in $lines) {
      if ($line -match '^\s*\[\s*(\d+)\]\s*(.+?)\s*\|\s*LCSC ID:\s*(C\d+)\s*\|\s*(.+?)\s*\|\s*3D model:\s*(\w+)') {
        $entry = [pscustomobject]@{
          Text = ("{0}    {1}    {2}    3D:{3}" -f $Matches[2], $Matches[3], $Matches[4], $Matches[5])
          Cid  = $Matches[3]
        }
        [void]$script:ListResults.Items.Add($entry)
      }
    }
    if ($script:ListResults.Items.Count -gt 0) { $script:ListResults.SelectedIndex = 0 }
    $script:Status.Text = "共 $($script:ListResults.Items.Count) 条"
    Write-Log "「$q」搜到 $($script:ListResults.Items.Count) 个候选。"
  } catch {
    Write-Log "搜索失败：$($_.Exception.Message)"
    $script:Status.Text = '搜索失败'
  } finally {
    Set-Busy $false
  }
}

function Run-Convert([string[]]$cids) {
  if (-not $cids -or $cids.Count -eq 0) { Write-Log '没有可转换的元件。'; return }

  $outDir = $script:TxtOutput.Text.Trim()
  if (-not $outDir) { $outDir = 'D:\PCB\AD_Libs'; $script:TxtOutput.Text = $outDir }
  $libName = $script:TxtLib.Text.Trim()
  if (-not $libName) { $libName = 'ADLib'; $script:TxtLib.Text = $libName }
  if ($libName -match '[\\/:*?"<>|]') { Write-Log '库名不能包含 \ / : * ? " < > | 字符。'; return }
  # 勾了「追加」但目标库不存在时：自动对齐文件夹里已有的库
  if ($script:ChkAppend.Checked) {
    $targetLib = Join-Path $outDir ($libName + '.SchLib')
    if (-not (Test-Path $targetLib)) {
      $existing = @(Get-ChildItem $outDir -Filter '*.SchLib' -File -ErrorAction SilentlyContinue |
        Where-Object { $_.BaseName -ne $libName } | Sort-Object Length -Descending)
      if ($existing.Count -eq 1 -and $script:AutoYes) {
        $libName = $existing[0].BaseName
        Write-Log "自动追加到已有库：$libName"
      } elseif ($existing.Count -eq 1) {
        $msg = "这个文件夹里已经有库：`n`n    $($existing[0].BaseName)`n`n要把这次的元件追加到它里面吗？`n`n是：追加到 $($existing[0].BaseName)`n否：新建一个叫 $libName 的库"
        $ans = [System.Windows.Forms.MessageBox]::Show($msg, '追加到哪个库？',
          [System.Windows.Forms.MessageBoxButtons]::YesNo,
          [System.Windows.Forms.MessageBoxIcon]::Question,
          [System.Windows.Forms.MessageBoxDefaultButton]::Button1)
        if ($ans -eq [System.Windows.Forms.DialogResult]::Yes) { $libName = $existing[0].BaseName; Write-Log "改为追加到已有库：$libName" }
      } elseif ($existing.Count -ge 2) {
        Write-Log "这个文件夹里已有多套库：$((($existing | ForEach-Object { $_.BaseName }) -join ' / '))"
        Write-Log "把「库名」改成要追加的那个，否则会新建 $libName。"
      }
    }
    if (-not (Test-Path (Join-Path $outDir ($libName + '.SchLib')))) {
      Write-Log "$libName 还不存在，这次会新建它（第一次必然是新库）。"
    }
  }

  New-Item -ItemType Directory -Force -Path $outDir | Out-Null
  Save-Config

  # 官方优先：输出目录下的 _official 子目录
  $officialDir = Join-Path $outDir '_official'
  $officialFiles = @{}
  $rest = @()
  foreach ($cid in $cids) {
    $hit = @()
    if (Test-Path $officialDir) {
      $hit = @(Get-ChildItem $officialDir -Recurse -File -ErrorAction SilentlyContinue |
        Where-Object { $_.Extension -in '.SchLib', '.PcbLib' -and $_.BaseName -like "*$cid*" })
      if ($hit.Count -eq 0) {
        $sub = Join-Path $officialDir $cid
        if (Test-Path $sub) { $hit = @(Get-ChildItem $sub -File -ErrorAction SilentlyContinue | Where-Object { $_.Extension -in '.SchLib', '.PcbLib' }) }
      }
    }
    if ($hit.Count -gt 0) {
      $officialFiles[$cid] = $hit
    } else {
      $rest += $cid
    }
  }
  if ($officialFiles.Count -gt 0) {
    foreach ($cid in $officialFiles.Keys) {
      foreach ($f in $officialFiles[$cid]) {
        Copy-Item $f.FullName (Join-Path $outDir $f.Name) -Force -ErrorAction SilentlyContinue
      }
      Write-Log "  [$cid] 使用官方库：$(($officialFiles[$cid] | ForEach-Object { $_.Name }) -join ', ')"
    }
  }
  if ($rest.Count -eq 0) {
    Write-Log "全部 $($cids.Count) 个元件都用了官方库，跳过 npnp 转换。"
    Set-Busy $false
    return
  }
  $cids = $rest

  $idFile = Join-Path $env:TEMP ('jlc2ad_ids_' + [guid]::NewGuid().ToString('N') + '.txt')
  Set-Content -LiteralPath $idFile -Value ($cids -join "`r`n") -Encoding ASCII

  $argList = @('altium', '-i', $idFile, '--output', $outDir, '--name', $libName, '--full')
  if ($script:ChkAppend.Checked) { $argList += '--append' } else { $argList += '--force' }

  Set-Busy $true
  $no3d = [bool]$script:ChkNo3D.Checked
  if ($no3d) { Write-Log '不导入 3D：本次拦截 3D 模型下载，只导出符号和封装。' }
  $script:Status.Text = "转换中 $($cids.Count) 个…"
  Write-Log "转换 $($cids.Count) 个 → $outDir\$libName"
  try {
    if ($no3d) { $r = Invoke-NpnpNoModel $argList } else { $r = Invoke-Npnp $argList }
    $all = "$($r.Out)`n$($r.Err)"
    # 拦截 3D 偶尔会连带影响接口（比如立创主站临时不可用），失败就退回普通模式
    if ($no3d -and $r.Code -ne 0 -and -not ($r.Out -match 'Success:\s*[1-9]') -and
        $all -match 'request failed|error sending request|连接|proxy|dns|timed out|超时') {
      Write-Log '不导入 3D 模式连不上立创接口，改用普通模式（带 3D）重试一次…'
      $r = Invoke-Npnp $argList
      $no3d = $false
    }
    foreach ($line in @($r.Out -split "`r?`n")) { if ($line.Trim()) { Write-Log $line.Trim() } }
    if ($r.Out -match 'Success:\s*(\d+)\s*\|\s*Failed:\s*(\d+)') {
      Write-Log "合计：成功 $($Matches[1])，失败 $($Matches[2])"
    }
    if ($r.Err.Trim()) { Write-Log "提示：$($r.Err.Trim())" }
    if ($r.Code -eq 0) { $script:Status.Text = '完成' } else { $script:Status.Text = "失败（$($r.Code)）" }

    foreach ($ext in 'SchLib', 'PcbLib') {
      $f = Join-Path $outDir ($libName + '.' + $ext)
      if (Test-Path $f) { Write-Log ("  " + $f + "  " + [math]::Round((Get-Item $f).Length / 1KB, 0) + " KB") }
    }

    if ($no3d) {
      $pcb = Join-Path $outDir ($libName + '.PcbLib')
      if (Test-Path $pcb) {
        $hasStep = Test-PcbLibHasStep $pcb
        if ($hasStep -eq $true) {
          Write-Log '注意：库里仍有 3D 数据，可能是之前追加进来的元件自带模型。'
        } elseif ($hasStep -eq $false) {
          Write-Log '已确认：本次没有嵌入 3D 模型。'
        }
      }
    }
  } catch {
    Write-Log "转换异常：$($_.Exception.Message)"
    $script:Status.Text = '异常'
  } finally {
    Remove-Item $idFile -Force -ErrorAction SilentlyContinue
    Set-Busy $false
  }
}

function Do-ConvertMain {
  $tokens = @($script:TxtInput.Text -split "`r?`n" | ForEach-Object { $_.Trim() } | Where-Object { $_ })
  if ($tokens.Count -gt 0) { Do-ConvertInput; return }

  $items = @($script:ListResults.Items)
  if ($items.Count -eq 0) {
    Write-Log '输入框是空的，也还没导入 BOM。'
    return
  }
  $matched = @($items | Where-Object { $_.Cid })
  $unmatched = @($items | Where-Object { -not $_.Cid })

  if ($matched.Count -eq 0) {
    Write-Log "列表里 $($unmatched.Count) 个都没匹配到立创编号，没法转换。先点「导出待手工…」补齐型号。"
    return
  }

  if ($unmatched.Count -gt 0) {
    Write-Log "列表：已匹配 $($matched.Count) 个，未匹配 $($unmatched.Count) 个。"
    if (-not $script:AutoYes) {
      $msg = "当前列表里：`n`n    已匹配  $($matched.Count) 个`n    未匹配  $($unmatched.Count) 个`n`n要把已匹配的 $($matched.Count) 个合并进库吗？`n（未匹配的不会转换，可以先点「导出待手工…」补齐）"
      $ans = [System.Windows.Forms.MessageBox]::Show(
        $msg, '确认转换',
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Question,
        [System.Windows.Forms.MessageBoxDefaultButton]::Button1)
      if ($ans -ne [System.Windows.Forms.DialogResult]::Yes) {
        Write-Log '已取消转换。'
        return
      }
    } else {
      Write-Log '（自动确认）只转换已匹配项。'
    }
  }

  Run-Convert @($matched | ForEach-Object { $_.Cid })
}

function Do-ConvertInput {
  $tokens = @($script:TxtInput.Text -split "`r?`n" | ForEach-Object { $_.Trim() } | Where-Object { $_ })
  if ($tokens.Count -eq 0) { Write-Log '请先在输入框里写元件。'; return }
  Set-Busy $true
  $cids = @()
  try {
    foreach ($tok in $tokens) {
      $cid = Resolve-Cid $tok
      if ($cid) {
        $cids += $cid
        if ($tok -ne $cid) { Write-Log "解析 $tok → $cid" }
      } else {
        Write-Log "跳过 $tok（没搜到）"
      }
    }
  } finally {
    Set-Busy $false
  }
  Run-Convert $cids
}

function Read-SharedBytes([string]$path) {
  $fs = [IO.File]::Open($path, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite)
  try {
    $ms = New-Object IO.MemoryStream
    $fs.CopyTo($ms)
    return $ms.ToArray()
  } finally {
    $fs.Dispose()
  }
}

function Read-TextSmart([string]$path) {
  $bytes = Read-SharedBytes $path
  try {
    $t = [Text.Encoding]::GetEncoding(65001).GetString($bytes)
    if ($t -notmatch [char]0xFFFD) { return $t }
  } catch { }
  try { return [Text.Encoding]::GetEncoding(936).GetString($bytes) } catch { return [Text.Encoding]::Default.GetString($bytes) }
}

function Read-XlsxRows([string]$path) {
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  $fsZip = [IO.File]::Open($path, [IO.FileMode]::Open, [IO.FileAccess]::Read, [IO.FileShare]::ReadWrite)
  $zip = New-Object System.IO.Compression.ZipArchive ($fsZip, [System.IO.Compression.ZipArchiveMode]::Read)
  $shared = @()
  $ss = $zip.Entries | Where-Object { $_.FullName -eq 'xl/sharedStrings.xml' }
  if ($ss) {
    $sr = New-Object IO.StreamReader($ss.Open())
    $x = $sr.ReadToEnd(); $sr.Close()
    foreach ($m in [regex]::Matches($x, '<si>(.*?)</si>', 'Singleline')) {
      $t = ''
      foreach ($tm in [regex]::Matches($m.Groups[1].Value, '<t[^>]*>(.*?)</t>', 'Singleline')) { $t += $tm.Groups[1].Value }
      $shared += $t
    }
  }
  $cells = @{}
  $sheet = $zip.Entries | Where-Object { $_.FullName -match '^xl/worksheets/sheet1\.xml$' }
  if ($sheet) {
    $sr2 = New-Object IO.StreamReader($sheet.Open())
    $st = $sr2.ReadToEnd(); $sr2.Close()
    foreach ($cm in [regex]::Matches($st, '<c r="([A-Z]+)(\d+)"([^>]*)>(.*?)</c>', 'Singleline')) {
      $col = $cm.Groups[1].Value
      $rn = [int]$cm.Groups[2].Value
      $attrs = $cm.Groups[3].Value
      $body = $cm.Groups[4].Value
      $val = ''
      if ($attrs -match 't="s"') {
        $vm = [regex]::Match($body, '<v>(\d+)</v>')
        if ($vm.Success) {
          $idx = [int]$vm.Groups[1].Value
          if ($idx -lt $shared.Count) { $val = $shared[$idx] }
        }
      } elseif ($attrs -match 't="(inlineStr|str)"') {
        foreach ($tm in [regex]::Matches($body, '<t[^>]*>(.*?)</t>', 'Singleline')) { $val += $tm.Groups[1].Value }
        if (-not $val) { $vm = [regex]::Match($body, '<v>(.*?)</v>'); if ($vm.Success) { $val = $vm.Groups[1].Value } }
      } else {
        $vm = [regex]::Match($body, '<v>(.*?)</v>')
        if ($vm.Success) { $val = $vm.Groups[1].Value }
      }
      if (-not $cells.ContainsKey($rn)) { $cells[$rn] = @{} }
      $cells[$rn][$col] = $val
    }
  }
  $zip.Dispose()
  $fsZip.Dispose()
  $out = @()
  foreach ($rn in ($cells.Keys | Sort-Object)) {
    $row = @()
    foreach ($col in ($cells[$rn].Keys | Sort-Object)) { $row += $cells[$rn][$col] }
    $out += , $row
  }
  return $out
}

function Read-BomRows([string]$path) {
  $ext = [IO.Path]::GetExtension($path).ToLower()
  if ($ext -eq '.xlsx' -or $ext -eq '.xlsm') { return Read-XlsxRows $path }
  $text = Read-TextSmart $path
  $rows = @()
  foreach ($line in ($text -split "`r?`n")) {
    if (-not $line.Trim()) { continue }
    $cells = @()
    $cur = ''
    $inQ = $false
    foreach ($ch in $line.ToCharArray()) {
      if ($ch -eq '"') { $inQ = -not $inQ; continue }
      if (-not $inQ -and ($ch -eq ',' -or $ch -eq "`t" -or $ch -eq ';')) { $cells += $cur; $cur = ''; continue }
      $cur += $ch
    }
    $cells += $cur
    $clean = @()
    foreach ($cellText in $cells) { $clean += $cellText.Trim() }
    $rows += , $clean
  }
  return $rows
}

function Clean-PartName([string]$s) {
  if (-not $s) { return '' }
  $s = $s -replace '（[^）]*）', ' '
  $s = $s -replace '\([^\)]*\)', ' '
  $s = $s -replace '见原图.*$', ''
  $s = $s.Trim()
  $s = $s.Trim('，', ',', '、', ';')
  return $s.Trim()
}

function Test-PartLike([string]$s) {
  if (-not $s) { return $false }
  $t = $s.Trim()
  if ($t.Length -lt 4 -or $t.Length -gt 60) { return $false }
  if ($t -match '^\d') { return $false }
  if ($t -match '^[A-Za-z]{1,3}\d{1,3}$') { return $false }
  if ($t -match '^[A-Za-z]{1,3}\d{1,3}\s*[-~]\s*[A-Za-z]{1,3}\d{1,3}$') { return $false }
  if ($t -match '^(见|同|参考|沿用|原)') { return $false }
  if ($t -match '^(SOT|SOP|ESOP|MSOP|SSOP|TQFN|QFN|DFN|LQFP|TSSOP|DIP|BGA|SMA|SMB|SMC|TO|PLCC|WROOM)[\s\-\d]' ) { return $false }
  if ($t -match '^\d+\.?\d*x\d+') { return $false }
  if ($t -match '^(PCB|DNP|NC|N/A|OLED|LED)$') { return $false }
  $latin = ([regex]::Matches($t, '[A-Za-z]')).Count
  if ($latin -lt 2) { return $false }
  return $true
}

function Pick-PartName($row) {
  $best = $null
  $bestScore = -1
  foreach ($cell in $row) {
    $v = [string]$cell
    if (-not (Test-PartLike $v)) { continue }
    $score = 0
    if ($v -match '^[Cc]\d{4,8}$') { $score += 10 }
    if ($v -match '[A-Za-z]' -and $v -match '\d') { $score += 2 }
    if ($v -match '[-_/]') { $score += 1 }
    if ($v.Length -ge 8) { $score += 1 }
    if ($score -gt $bestScore) { $bestScore = $score; $best = $v }
  }
  return $best
}

function Export-Manual([string]$path) {
  $list = @($script:ListResults.Items)
  $pending = @($list | Where-Object { -not $_.Cid })
  if ($pending.Count -eq 0) { Write-Log '当前没有待手工的行。'; return $false }

  $lines = New-Object System.Collections.ArrayList
  [void]$lines.Add('序号,位号,型号/规格,封装,立创编号,原始行')
  $i = 0
  foreach ($item in $pending) {
    $i++
    $raw = @($item.Raw)
    if ($raw.Count -eq 0) { $raw = @($item.Text) }
    $designator = if ($raw.Count -gt 0) { [string]$raw[0] } else { '' }
    $model = if ($raw.Count -gt 1) { [string]$raw[1] } else { '' }
    $pkg = if ($raw.Count -gt 2) { [string]$raw[2] } else { '' }
    $cells = @([string]$i, $designator, $model, $pkg, '', ($raw -join ' | '))
    $out = foreach ($v in $cells) {
      if ($v -match '[",\r\n]') { '"' + $v.Replace('"', '""') + '"' } else { $v }
    }
    [void]$lines.Add(($out -join ','))
  }
  [IO.File]::WriteAllLines($path, $lines, (New-Object Text.UTF8Encoding($true)))
  Write-Log "已导出待手工清单：$($pending.Count) 行 → $path"
  Write-Log '在「立创编号」列填好 C 编号后，把这个文件再拖进来即可直接转换。'
  return $true
}

function Import-Bom([string]$path) {
  try { $rows = Read-BomRows $path } catch { Write-Log "读取 BOM 失败：$($_.Exception.Message)"; return }
  $rowList = @($rows)
  if ($rowList.Count -lt 2) { Write-Log 'BOM 里没读到有效数据（至少需要表头+一行）。'; return }

  $header = @($rowList[0])
  $col = -1
  for ($i = 0; $i -lt $header.Count; $i++) {
    if ($header[$i] -match '型号|器件|物料|part|comment|description|料号') { $col = $i; break }
  }

  $script:ListResults.Items.Clear()
  $ok = 0; $manual = 0
  $seen = @{}
  Set-Busy $true
  $script:LastBomDir = [IO.Path]::GetDirectoryName($path)
  $script:LastBomName = [IO.Path]::GetFileNameWithoutExtension($path)
  Write-Log "导入 BOM：$([IO.Path]::GetFileName($path))  共 $($rowList.Count - 1) 行$(if ($col -ge 0) { "，型号列 #$($col + 1)" } else { '，未识别到型号列' })"
  try {
    for ($r = 1; $r -lt $rowList.Count; $r++) {
      $row = @($rowList[$r])
      if ($row.Count -eq 0) { continue }

      $name = $null
      $rowCid = $null
      foreach ($cell in $row) {
        $cv = ([string]$cell).Trim()
        if ($cv -match '^[Cc]\d{4,8}$') { $rowCid = $cv.ToUpper(); break }
      }
      if ($rowCid) { $name = $rowCid }
      if (-not $name -and $col -ge 0 -and $col -lt $row.Count) {
        $cellVal = ([string]$row[$col]).Trim()
        if (Test-PartLike $cellVal) { $name = $cellVal }
        elseif ($cellVal) {
          $summary = ($row | Where-Object { ([string]$_).Trim() } | Select-Object -First 3) -join ' / '
          [void]$script:ListResults.Items.Add([pscustomobject]@{ Text = "（需手工）$summary"; Cid = $null; Raw = $row })
          $manual++
          continue
        }
      }
      if (-not $name) { $name = Pick-PartName $row }

      if (-not $name) {
        $summary = ($row | Where-Object { ([string]$_).Trim() } | Select-Object -First 3) -join ' / '
        [void]$script:ListResults.Items.Add([pscustomobject]@{ Text = "（需手工）$summary"; Cid = $null; Raw = $row })
        $manual++
        continue
      }
      if ($seen.ContainsKey($name)) { continue }
      $seen[$name] = 1

      if ($name -match '^[Cc]\d{4,8}$') {
        $cid = $name.ToUpper()
        $label = $name
      } else {
        $res = Invoke-Npnp @('search', $name, '--limit', '1')
        $m = [regex]::Match($res.Out, '\[\s*\d+\]\s*(.+?)\s*\|\s*LCSC ID:\s*(C\d+)')
        if ($m.Success) {
          $cid = $m.Groups[2].Value
          $label = "$name   →   $($m.Groups[1].Value)   [$cid]"
        } else {
          $cid = $null
          $label = "$name   →   （未匹配）"
          $manual++
        }
      }
      [void]$script:ListResults.Items.Add([pscustomobject]@{ Text = $label; Cid = $cid; Raw = $row })
      if ($cid) { $ok++ }
    }
    for ($i = 0; $i -lt $script:ListResults.Items.Count; $i++) {
      if ($script:ListResults.Items[$i].Cid) { $script:ListResults.SetSelected($i, $true) }
    }
    $script:Status.Text = "BOM：$ok 匹配 / $manual 需手工"
    Write-Log "解析完成：$ok 个已匹配，$manual 个需手工（电阻电容、通用件、外设这些按型号搜不准，请手工指定）。"
    Write-Log '核对列表后点「仅转换选中项」；需要手工的可以直接把型号补进上面的输入框再转。'
  } finally {
    Set-Busy $false
  }
}
function Do-ConvertSelected {
  $sel = @($script:ListResults.SelectedItems)
  if ($sel.Count -eq 0) { Write-Log '没有选中项。'; return }
  Run-Convert @($sel | ForEach-Object { $_.Cid })
}

$script:BtnBom.Add_Click({
  $dlg = New-Object System.Windows.Forms.OpenFileDialog
  $dlg.Title = '选择 BOM 文件'
  $dlg.Filter = 'BOM 文件 (*.csv;*.xlsx;*.xlsm;*.txt;*.tsv)|*.csv;*.xlsx;*.xlsm;*.txt;*.tsv|所有文件 (*.*)|*.*'
  if ($dlg.ShowDialog() -eq 'OK') { Import-Bom $dlg.FileName }
})
$form.AllowDrop = $true
$form.Add_DragEnter({
  param($sender, $e)
  if ($e.Data.GetDataPresent([System.Windows.Forms.DataFormats]::FileDrop)) { $e.Effect = [System.Windows.Forms.DragDropEffects]::Copy }
})
$form.Add_DragDrop({
  param($sender, $e)
  $files = $e.Data.GetData([System.Windows.Forms.DataFormats]::FileDrop)
  if ($files -and $files.Count -gt 0) { Import-Bom $files[0] }
})
$script:BtnManual.Add_Click({
  $suggest = '待手工清单.csv'
  if ($script:LastBomName) { $suggest = $script:LastBomName + '_待手工.csv' }
  $dlg = New-Object System.Windows.Forms.SaveFileDialog
  $dlg.Title = '导出待手工清单'
  $dlg.Filter = 'CSV 文件 (*.csv)|*.csv'
  $dlg.FileName = $suggest
  if ($script:LastBomDir -and (Test-Path $script:LastBomDir)) { $dlg.InitialDirectory = $script:LastBomDir }
  if ($dlg.ShowDialog() -eq 'OK') { [void](Export-Manual $dlg.FileName) }
})
$script:BtnSearch.Add_Click({ Do-Search })
$script:BtnConvert.Add_Click({ Do-ConvertMain })
$script:BtnConvertSel.Add_Click({ Do-ConvertSelected })
$script:ListResults.Add_DoubleClick({ Do-ConvertSelected })
$script:BtnBrowse.Add_Click({
  $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
  $dlg.Description = '选择 AD 库输出文件夹'
  if (Test-Path $script:TxtOutput.Text.Trim()) { $dlg.SelectedPath = $script:TxtOutput.Text.Trim() }
  if ($dlg.ShowDialog() -eq 'OK') { $script:TxtOutput.Text = $dlg.SelectedPath; Save-Config }
})
$script:BtnOpen.Add_Click({
  $d = $script:TxtOutput.Text.Trim()
  if (Test-Path $d) { Start-Process explorer.exe $d } else { Write-Log '文件夹还不存在。' }
})
$script:TxtOutput.Add_Leave({ if (-not $script:Loading) { Save-Config } })
$script:TxtLib.Add_Leave({ if (-not $script:Loading) { Save-Config } })
$script:ChkAppend.Add_CheckedChanged({ if (-not $script:Loading) { Save-Config } })
$script:ChkNo3D.Add_CheckedChanged({ if (-not $script:Loading) { Save-Config } })
$form.Add_FormClosing({ Save-Config })

Write-Log '就绪。多行输入元件，点「批量转换并合并」攒进同一个库。'
Write-Log "输出 $($script:TxtOutput.Text)  ·  库 $($script:TxtLib.Text)"
if ($script:ChkNo3D.Checked) { Write-Log '「不导入 3D 模型」已勾选：只导出符号和封装。' }

if ($ConvertTest) {
  $script:TxtOutput.Text = (Join-Path $script:Root 'convtest')
  $script:TxtLib.Text = 'NewLib'
  $script:ChkAppend.Checked = $true
  Import-Bom $BomTest
  Do-ConvertMain
  return
}

if ($ManualTest) {
  Import-Bom $BomTest
  $ok = Export-Manual $ManualTest
  Write-Output ("EXPORTED=" + $ok)
  return
}

if ($BomTest) {
  $probe = Read-BomRows $BomTest
  Write-Output ("DEBUG rows=" + @($probe).Count)
  if (@($probe).Count -gt 0) { Write-Output ("DEBUG row0=" + ((@($probe)[0]) -join ' | ')) }
  if (@($probe).Count -gt 1) { Write-Output ("DEBUG row1=" + ((@($probe)[1]) -join ' | ')) }
  Import-Bom $BomTest
  foreach ($item in $script:ListResults.Items) { Write-Output $item.Text }
  return
}

if ($SelfTest) {
  $script:TxtInput.Text = "C25804`r`nSTM32F103C8T6"
  $script:TxtOutput.Text = (Join-Path $script:Root 'selftest')
  $script:TxtLib.Text = 'SelfTestLib'
  $script:ChkAppend.Checked = $true
  Do-ConvertInput
  return
}

[void]$form.ShowDialog()
